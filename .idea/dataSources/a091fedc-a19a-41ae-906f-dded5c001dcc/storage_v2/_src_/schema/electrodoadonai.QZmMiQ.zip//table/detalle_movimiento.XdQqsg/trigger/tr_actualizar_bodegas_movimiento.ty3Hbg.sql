create definer = root@localhost trigger tr_actualizar_bodegas_movimiento
    after insert
    on detalle_movimiento
    for each row
BEGIN
  -- Restar cantidad en bodega origen
  UPDATE bodega
  SET CNT_PRODUCTOS = CNT_PRODUCTOS - NEW.CNT_PRODUCTO_MOVIMIENTO
  WHERE ID_BODEGA = NEW.ID_BODEGA_ORIGEN;

  -- Sumar cantidad en bodega destino
  UPDATE bodega
  SET CNT_PRODUCTOS = CNT_PRODUCTOS + NEW.CNT_PRODUCTO_MOVIMIENTO
  WHERE ID_BODEGA = NEW.ID_BODEGA_DESTINO;

  -- Actualizar detalle_bodega para la bodega origen (restar cantidad del producto específico)
  UPDATE detalle_bodega
  SET CNT_PRODUCTO_BODEGA = CNT_PRODUCTO_BODEGA - NEW.CNT_PRODUCTO_MOVIMIENTO
  WHERE ID_BODEGA = NEW.ID_BODEGA_ORIGEN
    AND ID_PRODUCTO = NEW.ID_PRODUCTO;

  -- Actualizar detalle_bodega para la bodega destino (sumar cantidad del producto específico)
  UPDATE detalle_bodega
  SET CNT_PRODUCTO_BODEGA = CNT_PRODUCTO_BODEGA + NEW.CNT_PRODUCTO_MOVIMIENTO
  WHERE ID_BODEGA = NEW.ID_BODEGA_DESTINO
    AND ID_PRODUCTO = NEW.ID_PRODUCTO;

  -- En caso de que el producto aún no exista en la bodega destino, lo insertamos con la cantidad
  INSERT INTO detalle_bodega (ID_BODEGA, ID_PRODUCTO, CNT_PRODUCTO_BODEGA)
  SELECT NEW.ID_BODEGA_DESTINO, NEW.ID_PRODUCTO, NEW.CNT_PRODUCTO_MOVIMIENTO
  FROM DUAL
  WHERE NOT EXISTS (
    SELECT 1 FROM detalle_bodega
    WHERE ID_BODEGA = NEW.ID_BODEGA_DESTINO
      AND ID_PRODUCTO = NEW.ID_PRODUCTO
  );

END;

