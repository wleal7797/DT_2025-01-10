create definer = root@localhost trigger tr_validar_existencias_no_negativas
    before update
    on producto
    for each row
BEGIN
  IF NEW.EXISTENCIAS < 0 THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Error: las existencias del producto no pueden ser negativas';
  END IF;
END;

