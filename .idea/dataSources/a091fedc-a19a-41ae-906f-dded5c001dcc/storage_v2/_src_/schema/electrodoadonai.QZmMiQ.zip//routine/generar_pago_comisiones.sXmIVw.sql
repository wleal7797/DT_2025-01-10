create
    definer = root@localhost procedure generar_pago_comisiones()
BEGIN
    DECLARE comision_total DECIMAL(10,2);
    DECLARE adelantos_total DECIMAL(10,2);
    DECLARE saldo DECIMAL(10,2);
    DECLARE empleado_id INT;
    DECLARE done INT DEFAULT FALSE;

    -- Declarar cursor
    DECLARE cur CURSOR FOR
        SELECT V.ID_EMPLEADO, SUM(U.UTILIDAD_FINAL)
        FROM UTILIDADES_PR_PRODUCTO U
        JOIN DETALLE_VENTA DV ON U.ID_DETALLE_VENTA = DV.ID_DETALLE_VENTA
        JOIN VENTA V ON DV.ID_VENTA = V.ID_VENTA
        WHERE U.ESTADO = 'PENDIENTE'
        GROUP BY V.ID_EMPLEADO;

    -- Declarar manejador de finalización del cursor
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    -- Abrir cursor
    OPEN cur;

    read_loop: LOOP
        -- Obtener los datos del cursor
        FETCH cur INTO empleado_id, comision_total;
        
        -- Si no hay más filas, salir del bucle
        IF done THEN
            LEAVE read_loop;
        END IF;

        -- Obtener adelantos pendientes del empleado
        SELECT IFNULL(SUM(CNT_ADELANTO), 0) INTO adelantos_total
        FROM ADELANTOS
        WHERE ID_EMPLEADO = empleado_id
        AND ESTADO_ADELANTO = 'PENDIENTE';

        -- Calcular saldo final
        SET saldo = comision_total - adelantos_total;

        -- Insertar en PAGO_COMISIONES
        INSERT INTO PAGO_COMISIONES (COMISION, ID_ADELANTOS, SALDO, ESTADO, FECHA, ID_EMPLEADO)
        VALUES (comision_total, 
                (SELECT GROUP_CONCAT(ID_ADELANTO) FROM ADELANTOS WHERE ID_EMPLEADO = empleado_id AND ESTADO_ADELANTO = 'PENDIENTE'),
                saldo, 
                'PENDIENTE', 
                CURDATE(), 
                empleado_id);

        -- Marcar las utilidades como procesadas
        UPDATE UTILIDADES_PR_PRODUCTO
        SET ESTADO = 'PROCESADO'
        WHERE ID_DETALLE_VENTA IN (
            SELECT ID_DETALLE_VENTA FROM DETALLE_VENTA DV 
            JOIN VENTA V ON DV.ID_VENTA = V.ID_VENTA 
            WHERE V.ID_EMPLEADO = empleado_id
        );

        -- Marcar los adelantos como FINALIZADO si ya fueron descontados
        UPDATE ADELANTOS
        SET ESTADO_ADELANTO = 'FINALIZADO'
        WHERE ID_EMPLEADO = empleado_id
        AND ESTADO_ADELANTO = 'PENDIENTE';

    END LOOP;

    -- Cerrar cursor
    CLOSE cur;
END;

