create definer = root@localhost trigger tr_validar_stock_antes_movimiento
    before insert
    on detalle_movimiento
    for each row
BEGIN
  DECLARE cantidad_disponible INT;

  SELECT CNT_PRODUCTOS INTO cantidad_disponible
  FROM bodega
  WHERE ID_BODEGA = NEW.ID_BODEGA_ORIGEN;

  IF cantidad_disponible < NEW.CNT_PRODUCTO_MOVIMIENTO THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Error: no hay suficientes unidades en la bodega origen para mover';
  END IF;
END;

