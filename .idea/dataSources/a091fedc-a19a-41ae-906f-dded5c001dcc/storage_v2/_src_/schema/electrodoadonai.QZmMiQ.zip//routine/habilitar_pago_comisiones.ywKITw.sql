create
    definer = root@localhost procedure habilitar_pago_comisiones()
BEGIN
    -- Activar la bandera en la tabla configuración
    UPDATE configuracion SET activar_pago_comisiones = TRUE WHERE id_config = 1;
END;

