create definer = root@localhost trigger tr_validar_stock_antes_venta
    before insert
    on detalle_venta
    for each row
BEGIN
  DECLARE stock INT;

  -- Verifica existencias en producto
  SELECT EXISTENCIAS INTO stock
  FROM producto
  WHERE ID_PRODUCTO = NEW.ID_PRODUCTO;

  IF stock < NEW.CNT_PRODUCTO_VENTA THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Error: no hay suficiente inventario del producto';
  END IF;
END;

