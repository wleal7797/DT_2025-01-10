create definer = root@localhost trigger tr_descontar_stock_al_vender
    after insert
    on detalle_venta
    for each row
BEGIN
  -- Descontar del total de existencias del producto
  UPDATE producto
  SET EXISTENCIAS = EXISTENCIAS - NEW.CNT_PRODUCTO_VENTA
  WHERE ID_PRODUCTO = NEW.ID_PRODUCTO;

  -- Descontar de la bodega correspondiente
  UPDATE bodega
  SET CNT_PRODUCTOS = CNT_PRODUCTOS - NEW.CNT_PRODUCTO_VENTA
  WHERE ID_BODEGA = NEW.ID_BODEGA;
END;

