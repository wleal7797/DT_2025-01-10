create definer = root@localhost trigger trg_calcular_utilidad_producto
    after insert
    on detalle_venta
    for each row
BEGIN
    DECLARE costo_producto DECIMAL(10,2) DEFAULT 0;
    DECLARE utilidad_bruta DECIMAL(10,2);
    DECLARE utilidad_final DECIMAL(10,2);
    DECLARE producto_id INT;
    DECLARE detalle_bodega_id INT;

    -- Obtener el ID del producto desde la inserción en DETALLE_VENTA
    SET producto_id = NEW.ID_PRODUCTO;

    -- Obtener el ID_DETALLE_BODEGA relacionado con ese producto
    SELECT ID_DETALLE_BODEGA INTO detalle_bodega_id
    FROM DETALLE_BODEGA
    WHERE ID_PRODUCTO = producto_id
    LIMIT 1;

    -- Obtener el costo del producto
    SELECT IFNULL(COSTO, 0) INTO costo_producto
    FROM PRODUCTO
    WHERE ID_PRODUCTO = producto_id;

    -- Si el costo del producto es NULL o no se encuentra, se maneja adecuadamente
    IF costo_producto IS NULL THEN
        SET costo_producto = 0;
    END IF;

    -- Calcular utilidades
    SET utilidad_bruta = (NEW.PRECIO_VENTA_PRODUCTO - costo_producto) * NEW.CNT_PRODUCTO_VENTA;
    SET utilidad_final = utilidad_bruta * 0.50;

    -- Insertar en UTILIDADES_PR_PRODUCTO solo si utilidad_bruta no es NULL
    IF utilidad_bruta IS NOT NULL THEN
        INSERT INTO UTILIDADES_PR_PRODUCTO (UTILIDAD_BRUTA, UTILIDAD_FINAL, ID_PRODUCTO, ID_DETALLE_VENTA, ESTADO)
        VALUES (utilidad_bruta, utilidad_final, producto_id, NEW.ID_DETALLE_VENTA, 'PENDIENTE');
    END IF;
END;

